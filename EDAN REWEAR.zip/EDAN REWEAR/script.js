document.addEventListener("DOMContentLoaded", () => {
    const authContainer = document.getElementById("auth-container");
    const mainContainer = document.getElementById("main-container");
    const privacyPolicyContainer = document.getElementById("privacy-policy-container");

    document.getElementById("auth-form").addEventListener("submit", (e) => {
        e.preventDefault();
        authContainer.style.display = "none";
        mainContainer.style.display = "block";
    });

    document.getElementById("privacy-policy-link").addEventListener("click", () => {
        authContainer.style.display = "none";
        privacyPolicyContainer.style.display = "block";
    });

    document.getElementById("close-privacy-policy").addEventListener("click", () => {
        privacyPolicyContainer.style.display = "none";
        authContainer.style.display = "block";
    });

    document.getElementById("add-item-form").addEventListener("submit", (e) => {
        e.preventDefault();
        const itemName = document.getElementById("item-name").value;
        const itemDescription = document.getElementById("item-description").value;
        const itemPrice = document.getElementById("item-price").value;
        const itemCategory = document.getElementById("item-category").value;
        const itemImage = document.getElementById("item-image").files[0];
        
        const listItem = document.createElement("li");

        const reader = new FileReader();
        reader.onload = (e) => {
            const img = document.createElement("img");
            img.src = e.target.result;
            listItem.appendChild(img);
        };
        reader.readAsDataURL(itemImage);

        listItem.innerHTML += `<h3>${itemName}</h3><p>${itemDescription}</p><p>Precio: $${itemPrice}</p>`;
        document.getElementById("items-list").appendChild(listItem);
        document.getElementById("add-item-form").reset();
    });

    document.getElementById("chat-form").addEventListener("submit", (e) => {
        e.preventDefault();
        const chatMessage = document.getElementById("chat-message").value;
        const messageElem = document.createElement("div");
        messageElem.textContent = chatMessage;
        document.getElementById("chat-box").appendChild(messageElem);
        document.getElementById("chat-form").reset();
    });
});
